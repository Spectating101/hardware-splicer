# Mecha-Splicer Mint Summary

- Bundle root: `/tmp/mecha_mint_zip_demo/20260201_183151`
- Signals total: 9
- Picked categories: enclosure, mount

## enclosure
- Path: `/tmp/mecha_mint_zip_demo/20260201_183151/enclosure`
- Outputs: `enclosure.scad`
- Est. COGS (USD): 35.0

## mount
- Path: `/tmp/mecha_mint_zip_demo/20260201_183151/mount`
- Outputs: `bracket.scad`
- Est. COGS (USD): 12.0
