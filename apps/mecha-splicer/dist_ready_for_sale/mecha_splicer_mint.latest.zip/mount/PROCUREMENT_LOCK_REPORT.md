# Procurement Lock Report

- Lines: 3
- Locked: 1
- Missing SKU: 2
- Est. COGS (USD, catalog/overrides): $12.00

## Missing

- M3 nuts (M3 hex) — no SKU mapped
- M3 washers (M3) — no SKU mapped
