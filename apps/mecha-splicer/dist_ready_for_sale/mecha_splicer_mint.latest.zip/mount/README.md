# Mecha-Splicer Bundle: mint_bracket_plate

## Outputs
- `bracket.scad`

## BOM
- 2× M3 screws (M3×12)
- 2× M3 nuts (M3 hex)
- 2× M3 washers (M3)

## DFM Notes
