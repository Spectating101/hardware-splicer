# Mechanical Sanity Check

This is a conservative checklist (not simulation).

- ✅ No DFM warnings emitted by heuristic checks.
