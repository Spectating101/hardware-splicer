# Build Recipe

## Outputs
- `enclosure.scad`

## Procurement
- `BUY_LIST.csv` (unlocked)
- `BUY_LIST.locked.csv` (after `SKU_OVERRIDES.json`)
- `PROCUREMENT_LOCK_REPORT.md`
- Est. COGS (USD): 35.0

## Assembly (prototype-grade)
- Print base + lid; test-fit PCB/module with clearance.
- Install heat-set inserts (optional) and fasteners.
- Verify connector cutouts and cable strain relief.
