# Mecha-Splicer Bundle: mint_enclosure_generic

## Outputs
- `enclosure.scad`

## BOM
- 4× M3 screws (M3×12)
- 4× M3 heat-set inserts (M3 heat-set)
- 4× rubber feet (self-adhesive)

## DFM Notes
