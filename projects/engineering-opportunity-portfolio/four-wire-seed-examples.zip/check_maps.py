"""Ideal end-to-end continuity of an unplugged four-wire harness."""
from ast import literal_eval
from itertools import combinations, permutations
from pathlib import Path

for name in ("straight", "crossed"):
    # Read only the final X2 list from these two bundled WireViz examples.
    source = Path(__file__).with_name(name + ".yml").read_text()
    x2 = literal_eval(source.split("    - X2: ")[1])
    pins = (1, 2, 3, 4)
    assert sorted(x2) == list(pins)
    correct = set(zip(pins, x2))
    assignments = [set(zip(pins, mapping)) for mapping in permutations(pins)]
    opens = [correct - {edge} for edge in correct]
    bridges = [
        correct | {(a, x2[b - 1]), (b, x2[a - 1])}
        for a, b in combinations(pins, 2)
    ]
    cases = assignments + opens + bridges
    assert len(set(map(frozenset, cases))) == 34
    assert sum(mapping == correct for mapping in cases) == 1
    print(f"{name}: one expected map and 33 distinguishable fault maps")
