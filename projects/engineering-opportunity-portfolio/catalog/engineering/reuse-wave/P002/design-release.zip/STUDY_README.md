# Ender-3 reference-donor pen plotter

This is an executable digital study for the registered case `ender3-penplotter`.
The backend generated its outputs in an isolated workspace and ran the native
verifier before sealing this package. No physical fit, operation, fabrication,
purchase or ownership of a donor is established by these results.

Start with [engineering results](<reports/engineering.json>) and
[native verification](<reports/verification.json>). The engineering report records
whether the selected numeric goals pass; a failed goal can be a valid completed
study. [Requirements](requirements.json), [source contract](study-contract.json) and
[artifact receipt](study-verification.json) preserve the case identity, source hashes, computed
claims and exact payload hashes. The backend export response supplies the project
and revision identity and SHA256 of the enclosing ZIP.

## Reproduce the native study

Extract this archive into a new working directory. Use a Python environment with
CadQuery, trimesh, numpy, Pillow and matplotlib, and run these included scripts
from the extracted directory:

```sh
python -B scripts/build.py
python -B scripts/simulate.py
python -B scripts/verify.py
```

The scripts use their own directory to locate inputs. The last stage checks the
exported geometry and recomputes the retained engineering evidence. Re-running
scripts changes local outputs and invalidates the old artifact receipt; submit a
new revision through the backend to obtain a new sealed package. The backend
accepts only the named numeric requirements for this case.

| Requirement | Selected value |
| --- | ---: |
| `drawing_width_mm` | 100 |
| `drawing_height_mm` | 80 |
| `pen_diameter_mm` | 10 |
| `pen_lift_mm` | 3 |

## Included source documentation

- [README.md](<README.md>)
- [ASSEMBLY.md](<ASSEMBLY.md>)
- [BOM.md](<BOM.md>)
- [VALIDATION.md](<VALIDATION.md>)
- [NOTICE.md](<NOTICE.md>)
- [sources/README.md](<sources/README.md>)

Captured source documentation may also describe a separate standalone delivery.
Its HS-import and standalone publication helpers are outside this executable
backend package. Use this page and the included scripts for this sealed study.
The [Hardware Splicer license](LICENSE_HS.txt) covers the backend package glue.
Vendor and case-specific source licenses remain beside their retained files.
