"""Apply Kemerd mass_row to the changed print solids in the registered FieldDeck study."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import zipfile
import cadquery as cq


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("study_zip", type=Path)
    parser.add_argument("kemerd_builder", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location("enclosure_builder", args.kemerd_builder)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = []
    with zipfile.ZipFile(args.study_zip) as study, tempfile.TemporaryDirectory() as tmp:
        geom = json.loads(study.read("revision/geometry.json"))
        items = {r["id"]:r for r in json.loads(study.read("revision/BOM.json"))["items"]}
        for change in geom["exports"]["exported_parts"]:
            name = change["part"]
            quantity = items[name]["quantity"]
            data = study.read(f"revision/cad/changed_parts/{name}.step")
            sha = hashlib.sha256(data).hexdigest()
            if quantity != change["quantity"] or sha != change["step_sha256"]:
                raise ValueError(f"STEP identity or BOM quantity differs for {name}")
            file = Path(tmp) / "part.step"
            file.write_bytes(data)
            wp = cq.importers.importStep(str(file))
            one, = wp.solids().vals()
            if not one.isValid() or one.Volume() <= 0:
                raise ValueError(f"Invalid solid for {name}")
            measured = module.mass_row(name, wp, "PETG", (0.5,0.5,0.5))
            rows.append({"part":name, "quantity":quantity, "step_sha256":sha,
                         "volume_mm3_each":measured["volume_mm3"], "solid_mass_g_each":measured["mass_g"]})
    result = {"method":"Kemerd mass_row on reopened changed STEP solids",
              "study_zip_sha256":hashlib.sha256(args.study_zip.read_bytes()).hexdigest(),
              "kemerd_script_sha256":hashlib.sha256(args.kemerd_builder.read_bytes()).hexdigest(),
              "material":"PETG", "density_g_cm3":module.DENS["PETG"], "changed_print_parts":rows,
              "total_solid_equivalent_g":round(sum(r["quantity"]*r["solid_mass_g_each"] for r in rows),3),
              "scope":"Fully dense changed parts only. Slicer settings, supports and waste are outside this estimate."}
    args.output.write_text(json.dumps(result,indent=2)+"\n")


if __name__ == "__main__":
    main()
