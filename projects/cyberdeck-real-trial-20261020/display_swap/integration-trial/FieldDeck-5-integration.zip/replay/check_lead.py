"""Check the declared SC1975 power lead in a FieldDeck digital study export."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

from copper_kicad.project import Project
from copper_kicad.sch.netlist import check_expectations, export_netlist
from copper_kicad.sch.ops import apply_ops
from kicad_cli_erc import run_kicad_cli_erc


def write(path, contents):
    path.write_text(json.dumps(contents, indent=2) + "\n")


def schematic(directory, reverse=False):
    directory.mkdir()
    # Register the same stock symbols KiCad will use for independent ERC.
    (directory / "sym-lib-table").write_text(
        '(sym_lib_table (version 7) (lib (name "Connector_Generic")(type "KiCad")'
        '(uri "${KICAD10_SYMBOL_DIR}/Connector_Generic.kicad_sym")(options "")(descr "")))'
    )
    project = Project(directory, "display_power")
    # J2 and J3 represent individual lead conductors, not SC1975 connector pin numbers.
    symbols = [
        ("J1", "Conn_01x06", "Pi GPIO physical pins 1-6 (excerpt)", [50.8, 60.96]),
        ("J2", "Conn_01x01", "Supplied lead - red conductor", [125.73, 50.8]),
        ("J3", "Conn_01x01", "Supplied lead - black conductor", [125.73, 76.2]),
    ]
    ops = [{"op": "place", "ref": ref, "lib_id": "Connector_Generic:" + lib,
            "value": value, "at": pos} for ref, lib, value, pos in symbols]
    # Other GPIO contacts are outside this harness drawing.
    ops.extend({"op": "no_connect", "pin": "J1." + n} for n in ("1", "3", "4", "5"))
    for net, source, end in [
        ("DISPLAY_5V", "J1.2", "J3.1" if reverse else "J2.1"),
        ("DISPLAY_GND", "J1.6", "J2.1" if reverse else "J3.1"),
    ]:
        ops.append({"op": "connect", "pins": [source, end], "net": net, "kind": "local"})
    apply_ops(project, ops)
    return project


def check(project):
    nets = export_netlist(project)
    expected = [{"net": "DISPLAY_5V", "pins": [["J1","2"],["J2","1"]]},
                {"net": "DISPLAY_GND", "pins": [["J1","6"],["J3","1"]]}]
    return nets, check_expectations(nets, expected)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("study_zip", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    with zipfile.ZipFile(args.study_zip) as z:
        connections = json.loads(z.read("revision/connections.json"))
        bom = {row["id"]: row for row in csv.DictReader(io.StringIO(z.read("revision/BOM.csv").decode()))}
    if (bom["display"]["mpn"] != "SC1975" or bom["gpio_extensions"]["mpn"] != "824" or
        not any(row["from"] == "Pi 4 GPIO 5 V and GND" and row["to"] == "SC1975 power input"
                for row in connections["display"])):
        raise ValueError("The selected display, lead or host connection differs from this study")
    args.output.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory() as temp:
        project = schematic(Path(temp) / "expected")
        netlist, result = check(project)
        _, negative = check(schematic(Path(temp) / "reversed", reverse=True))
        erc = run_kicad_cli_erc(project.sch, out_dir=args.output)
        if (result["ok"] != 4 or len(negative["mismatches"]) != 2 or erc["skipped"]
                or not erc["pass"]):
            raise ValueError({"positive":result, "negative":negative, "erc":erc})
        shutil.copyfile(project.dir / "sym-lib-table", args.output / "sym-lib-table")
        shutil.copyfile(project.sch, args.output / project.sch.name)
        subprocess.run(["kicad-cli","sch","export","pdf","-o",str(args.output/"display_power.pdf"),
                        str(project.sch)],check=True)
    erc.pop("report_path", None)
    write(args.output/"netlist.json", netlist)
    write(args.output/"lead_check.json", {"scope":"Declared two-conductor display power lead only",
          "study_zip_sha256":hashlib.sha256(args.study_zip.read_bytes()).hexdigest(),
          "positive":result, "reversed_control":negative, "erc":erc,
          "excluded":["DSI data pinout","measured voltage","contact current rating","physical fit"]})


if __name__ == "__main__":
    main()
