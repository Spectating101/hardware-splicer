# Ender-3 digital pen plotter revision 2

Open `registered-study.zip` for the 12 mm pen adapter, clamp CAD and 140 × 100 mm drawing study. The native audit is in `audit.json`. The study stores its own source, notices, replay and verification scripts.

`optimized-digital.gcode` is a candidate for digital replay of that drawing. vpype 1.15.0 reordered complete, direction-preserving strokes. HS replayed it independently. See `plotter-route.json` and `plotter-route.png` for the comparison. All 268 directed ink segments stayed identical. Ideal feed time excludes acceleration, pen settling and other hardware effects. Initial position, pen offset, bed datum and pen-up clearance are modeled assumptions. No machine was operated.
