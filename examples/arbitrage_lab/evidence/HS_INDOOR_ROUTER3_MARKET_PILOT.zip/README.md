# Mecha-Splicer Bundle: HS-MARGIN-PILOT-ROUTER3-INDOOR

## Outputs
- `indoor_router_mount.scad`

## BOM
- 2× indoor router support bracket (PETG FDM; two identical copies)
- 4× wall screws/anchors (M4 nominal, select for wall substrate)

## DFM Notes
- [warn] INDOOR ROUTER MOUNT IS A FIT/LOAD PROTOTYPE: print two pieces; physical router fit, FDM print orientation, 1kg+ static/load testing, wall anchor selection and heat/ventilation remain UNVERIFIED.
