// Authored by HS Mecha-Splicer; NOT a copy of seller/OEM CAD.
// Requires physical fit, loading, anchor and thermal verification.
// Quantity TWO for one router. Indoor wall only. No adhesive-only mounting.
$fn=64;
device_depth=43.40000;
fit_clearance=1.50000;
bracket_w=42.00000;
back_h=65.00000;
back_t=4.00000;
shelf_t=4.00000;
lip_h=14.00000;
lip_t=3.00000;
gusset_t=3.00000;
bolt_hole=4.50000;
bolt_pitch=27.00000;
total_depth=back_t+device_depth+fit_clearance*2+lip_t;
eps=0.08;

// L-section, with gussets OUTSIDE the central device-receiving section.
// Bottom is printable without support; z=0 lies on print bed.
module gusset(xpos) {
    // x-extruded triangular rib; three triangle vertices on each x face.
    polyhedron(
      points=[
        [xpos,0,0], [xpos,total_depth,0], [xpos,0,back_h*0.55],
        [xpos+gusset_t,0,0], [xpos+gusset_t,total_depth,0],
        [xpos+gusset_t,0,back_h*0.55]],
      faces=[[0,2,1],[3,4,5],[0,1,4,3],[1,2,5,4],[2,0,3,5]]);
}

module mount_piece() {
  difference() {
    union() {
      // wall plate and bottom supporting shelf
      cube([bracket_w,back_t,back_h]);
      cube([bracket_w,total_depth,shelf_t]);
      // positive front lip (unverified retention)
      translate([0,total_depth-lip_t,0])
        cube([bracket_w,lip_t,lip_h]);
      // side gussets: print geometry only; physical load unverified
      // triangular cross-section in Y/Z plane
      for(x=[0,bracket_w-gusset_t])
        gusset(x);
    }
    // Two M4 nominal through-holes, from wall-facing back to device-facing front.
    // Print-hole diameter/tolerance must be checked by calipers.
    for (z=[back_h/2-bolt_pitch/2,back_h/2+bolt_pitch/2])
      translate([bracket_w/2,-eps,z])
        rotate([-90,0,0])
          cylinder(h=back_t+2*eps,d=bolt_hole);
  }
}

mount_piece();
