# Intact input-device reuse: SOFTWARE REVIEW BUNDLE

Not a fabrication/READY package or physical validation. No purchased development board is substituted.

Run `python test_adapter.py` for offline synthetic replay. Run `python adapter.py < example-events.jsonl` to emit one symbolic action. Requires only Python's standard library.

The adapter consumes normalized events, NOT USB bytes, GPIO or evdev. It does not enumerate/select a device, inject keys, execute action names, flash, energize or contact hardware. An actual host bridge and observed device mapping remain unimplemented. Labels in contract.json are proposed logical bindings.

A connect/reconnect starts disarmed until a release. One press emits one action; repeated press events while held do not repeat. Other devices/buttons do not trigger it. A real bridge must report initial state and disconnects reliably; synthetic tests cannot establish that behavior.

contract.json contains source hashes, proposed mechanism and unresolved physical questions. No vendor-specific report layout, switch-node mapping, PCB geometry, force or safe stop dimension is inferred.
