"""Offline synthetic inputs, never measured USB/foot-pedal evidence."""
import importlib.util
import json
from pathlib import Path

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("delivered_adapter", root / "adapter.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
binding = json.loads((root / "contract.json").read_text())["interface"]
device, button = binding["device_alias"], binding["button"]
def event(kind, dev=device, btn=button):
    return {"type": kind, "device": dev, **({"button": btn} if kind in {"pressed", "released"} else {})}
connect, down, up, disconnect = [event(kind) for kind in ("connected", "pressed", "released", "disconnected")]
other_device = device + "_other"
other_button = button + "_other"
cases = [
    ("no_connection", [up, down, down], []),
    ("held_at_connect", [connect, down, down, up, down], [4]),
    ("hold_no_repeat", [connect, up] + [down] * 100, [2]),
    ("hundred_press_release_cycles", [connect, up] + [down, down, up] * 100, [2 + 3*n for n in range(100)]),
    ("other_device_isolated", [connect, up, event("pressed", other_device), event("disconnected", other_device), down], [4]),
    ("other_button_ignored", [connect, up, event("pressed", btn=other_button), event("released", btn=other_button), down], [4]),
    ("reconnect_requires_release", [connect, up, down, disconnect, up, down, connect, down, up, down], [2, 9]),
]
results = []
for name, events, expected_steps in cases:
    adapter = module.Adapter(**binding)
    emissions = [(step, action) for step, item in enumerate(events) for action in adapter.feed(item)]
    actual_steps = [step for step, action in emissions]
    actions = [action for step, action in emissions]
    expected = [{"type": "action", "action": binding["action"], "device_alias": device}] * len(expected_steps)
    results.append({"name": name, "pass": actions == expected and actual_steps == expected_steps,
                    "expected_actions": len(expected_steps), "actual_actions": len(actions),
                    "expected_action_steps": expected_steps, "actual_action_steps": actual_steps})
print(json.dumps({"kind": "synthetic_normalized_event_replay", "scenarios": results}, sort_keys=True))
raise SystemExit(0 if all(row["pass"] for row in results) else 1)
