# Assembly guide

1. **Gather parts**
   Collect 5 BOM line(s). Verify MPNs and donor harness labels before soldering.

2. **Fabricate or prepare carrier PCB**
   Order or mill the carrier board from KiCad outputs. Preview copper is not production-ready unless gates say otherwise.

3. **Bench measurements**
   Complete open evidence gates (DMM / PSU ramp / thermal) before energizing donor harnesses.

4. **First power-on**
   Authorized only when gates report power_on_authorized.
