# Wiring guide

## Net connections (compile graph)
- `{'nodeId': 'n1', 'pinId': 'V+'}` → `{'nodeId': 'n3', 'pinId': 'IN+'}`
- `{'nodeId': 'n1', 'pinId': 'GND'}` → `{'nodeId': 'n3', 'pinId': 'IN-'}`
- `{'nodeId': 'n2', 'pinId': 'V+'}` → `{'nodeId': 'n4', 'pinId': 'VIN'}`
- `{'nodeId': 'n2', 'pinId': 'GND'}` → `{'nodeId': 'n4', 'pinId': 'GND'}`
- `{'nodeId': 'n3', 'pinId': 'OUT+'}` → `{'nodeId': 'n5', 'pinId': 'VCC'}`
- `{'nodeId': 'n3', 'pinId': 'OUT-'}` → `{'nodeId': 'n5', 'pinId': 'GND'}`
- `{'nodeId': 'n4', 'pinId': 'GND'}` → `{'nodeId': 'n5', 'pinId': 'GND'}`
- `{'nodeId': 'n4', 'pinId': 'D2'}` → `{'nodeId': 'n5', 'pinId': 'IN1'}`
- `{'nodeId': 'n4', 'pinId': 'D3'}` → `{'nodeId': 'n5', 'pinId': 'IN2'}`
- `{'nodeId': 'n4', 'pinId': 'GPIO21'}` → `{'nodeId': 'n6', 'pinId': 'SDA'}`
- `{'nodeId': 'n4', 'pinId': 'GPIO22'}` → `{'nodeId': 'n6', 'pinId': 'SCL'}`
- `{'nodeId': 'n4', 'pinId': '3V3'}` → `{'nodeId': 'n6', 'pinId': 'VCC'}`
- `{'nodeId': 'n4', 'pinId': 'GND'}` → `{'nodeId': 'n6', 'pinId': 'GND'}`
