# Bench bring-up

**Goal:** Splice the motor driver and geared motors from a dead RC toy into a small robot drive base with a salvaged ESP32 controller
**Power:** barrel_12v

## Hookup

- **ESP32 DevKit (GND)** → **VL53L0X Time-of-Flight Sensor (GND)** — common ground
- **ESP32 DevKit (3V3)** → **VL53L0X Time-of-Flight Sensor (VCC)** — signal
- **ESP32 DevKit (GPIO21)** → **VL53L0X Time-of-Flight Sensor (SDA)** — I2C bus
- **ESP32 DevKit (GPIO22)** → **VL53L0X Time-of-Flight Sensor (SCL)** — I2C bus
- **ESP32 DevKit (GND)** → **L298N motor driver (GND)** — common ground
- **ESP32 DevKit (GPIO4)** → **L298N motor driver (IN1)** — control signal
- **ESP32 DevKit (GPIO2)** → **L298N motor driver (IN2)** — control signal
- **ESP32 DevKit (3V3)** → **L298N motor driver (VCC)** — signal
- **L298N motor driver (OUT1)** → **Mini DC Motor 3-6V (VCC)** — signal
- **L298N motor driver (OUT2)** → **Mini DC Motor 3-6V (GND)** — common ground

## Before you power on

- Confirm common ground between MCU, driver, and load before energizing.
- Measure supply voltage at the load before attaching pump/motor.
- Dry-run: GPIO high → driver output ON → load sees supply (no MCU on same rail without driver).
