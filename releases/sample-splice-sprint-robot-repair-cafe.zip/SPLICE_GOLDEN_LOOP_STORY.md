# Splice golden loop

End-to-end: donor intake → splice compile → bench template → capture → gate closure.

- **Build:** `robot_drive_base` (DRC pass: `True`)
- **Donor vision blocks applied:** 1
- **Bench before:** `bench_complete` (0 open gates)
- **Bench after:** `bench_complete` (power_on: `True`)
- **Simulated bench:** `True`
- **Loop pass:** `True`

Artifacts: `SPLICE_GOLDEN_LOOP_REPORT.json`, `BENCH_CAPTURE_TEMPLATE.json`, `SPLICE_BENCH_SESSION.json`
