# splice_salvaged_robot_drive_vision_repair

**Goal:** Splice the motor driver and geared motors from a dead RC toy into a small robot drive base with a salvaged ESP32 controller

**Summary:** ready_after_measurements

**Estimated cost (USD):** 59.0

## INFO
- Build ID: `robot_drive_base`
- Archetype: `rover`
- Clarification needed: `False`

## BOM
- Lines: **5**
- `dc_motor_3v_6v` — Mini DC Motor 3-6V × 1
- `esp32-devkit` — ESP32 DevKit (Wi-Fi/BLE MCU) × 1
- `vl53l0x_tof` — VL53L0X Time-of-Flight Sensor × 1
- `l298n` — L298N dual H-bridge × 1
- `usb-power-5v` — USB 5V power input × 1

## WIRING

# Wiring guide

## Net connections (compile graph)
- `{'nodeId': 'n1', 'pinId': 'V+'}` → `{'nodeId': 'n3', 'pinId': 'IN+'}`
- `{'nodeId': 'n1', 'pinId': 'GND'}` → `{'nodeId': 'n3', 'pinId': 'IN-'}`
- `{'nodeId': 'n2', 'pinId': 'V+'}` → `{'nodeId': 'n4', 'pinId': 'VIN'}`
- `{'nodeId': 'n2', 'pinId': 'GND'}` → `{'nodeId': 'n4', 'pinId': 'GND'}`
- `{'nodeId': 'n3', 'pinId': 'OUT+'}` → `{'nodeId': 'n5', 'pinId': 'VCC'}`
- `{'nodeId': 'n3', 'pinId': 'OUT-'}` → `{'nodeId': 'n5', 'pinId': 'GND'}`
- `{'nodeId': 'n4', 'pinId': 'GND'}` → `{'nodeId': 'n5', 'pinId': 'GND'}`
- `{'nodeId': 'n4', 'pinId': 'D2'}` → `{'nodeId': 'n5', 'pinId': 'IN1'}`
- `{'nodeId': 'n4', 'pinId': 'D3'}` → `{'nodeId': 'n5', 'pinId': 'IN2'}`
- `{'nodeId': 'n4', 'pinId': 'GPIO21'}` → `{'nodeId': 'n6', 'pinId': 'SDA'}`
- `{'nodeId': 'n4', 'pinId': 'GPIO22'}` → `{'nodeId': 'n6', 'pinId': 'SCL'}`
- `{'nodeId': 'n4', 'pinId': '3V3'}` → `{'nodeId': 'n6', 'pinId': 'VCC'}`
- `{'nodeId': 'n4', 'pinId': 'GND'}` → `{'nodeId': 'n6', 'pinId': 'GND'}`


## INSTRUCTIONS

1. **Gather parts** — Collect 5 BOM line(s). Verify MPNs and donor harness labels before soldering.
2. **Fabricate or prepare carrier PCB** — Order or mill the carrier board from KiCad outputs. Preview copper is not production-ready unless gates say otherwise.
3. **Bench measurements** — Complete open evidence gates (DMM / PSU ramp / thermal) before energizing donor harnesses.
4. **First power-on** — Authorized only when gates report power_on_authorized.

## GATES
- **Verdict:** `POWER_ON_AUTHORIZED`
- Compile OK: `True`
- Build ready: `True`
- Power-on authorized: `True`
- Fab recommendation: `—`
