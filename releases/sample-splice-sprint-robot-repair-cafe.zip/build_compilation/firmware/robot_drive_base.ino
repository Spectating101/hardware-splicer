// robot_drive_base — L298N serial motor commands
const int IN1 = 2;
const int IN2 = 3;

void setup() {
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  Serial.begin(115200);
}

void loop() {
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'f') { digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW); }
    if (c == 'b') { digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH); }
    if (c == 's') { digitalWrite(IN1, LOW); digitalWrite(IN2, LOW); }
  }
}
