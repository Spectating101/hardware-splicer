Hardware-Splicer fabrication package
build_id: robot_drive_base
build_ready: True
fabrication_ready: False
gerber_ready: False

Upload gerbers/ to your PCB house; verify BOM before ordering modules.