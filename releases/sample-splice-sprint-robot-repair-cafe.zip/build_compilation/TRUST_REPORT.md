Build `robot_drive_base` electrical trust report.
Trust level: **build_trusted** (score 1.00).
KiCad DRC: clean.
Simulation: pass (estimated load ~0.35A).
Warnings: Fab guidance: review_required_preview_copper
